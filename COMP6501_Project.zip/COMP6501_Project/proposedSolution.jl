using CSV, DataFrames
using JuMP
using Cbc

# Declaring the optimization model
m = Model(Cbc.Optimizer)

# Reading in the cricketStats4 file
df = DataFrame(CSV.File("cricketStats6.csv"))

# finding the length of the dataset
n = length(df[!,16])

bowlerCount = 0
batsmanCount=0
allRCount=0
wkCount=0
raa = 1
name = ""
cost = 0.0
fitness = 0
overseas = 0
avg = 0

#The RAAScorer() function populates the skill, name, cost, fitness, Overseas
#factor of each player into their respective type
function RAAScorer()
    bowlerSkill= Any[]
    bName = Any[]
    bCost = Any[]
    bFit = Any[]
    bOverseas = Any[]

    batsmanSkill = Any[]
    baName = Any[]
    baCost = Any[]
    baFit = Any[]
    baOverseas = Any[]

    allRSkill = Any[]
    arName = Any[]
    arCost = Any[]
    arFit = Any[]
    arOverseas = Any[]

    wkSkill = Any[]
    wktName = Any[]
    wktCost = Any[]
    wktFit = Any[]
    wktOverseas = Any[]

    bqualities = Any[]
    baqualities = Any[]
    arqualities = Any[]
    wktqualities = Any[]

    global bowlerCount
    global batsmanCount
    global allRCount
    global wkCount

    global raa
    global avg

    global bqualities
    global baqualities
    global arqualities
    global wktqualities

    global bowlerSkill
    global batsmanSkill
    global allRSkill
    global wkSkill
    global bName
    global baName
    global arName
    global wktName
    global bCost
    global baCost
    global arCost
    global wktCost
    global bFit
    global baFit
    global arFit
    global wktFit
    global baOverseas
    global baOverseas
    global arOverseas
    global wktOverseas

    for i = 1:n

        raa = df[i,4]

        name = df[i,2]

        fitness = df[i,11]

        overseas = df[i,10]

        cost = replace.(df[i,7],[',','$','\\','.'] => "")
        if (occursin("NA",df[i,7]))
            cost = replace.(cost,['N','A']=>"0")
        else
            cost = chop(cost,tail=2)
        end

        if (occursin("Dom", df[i,10]))
            overseas=0
        else
            overseas=1
        end

        avg = (df[i,12] + df[i,13] + df[i,14] + df[i,15] + df[i,16])/5


        if (occursin("BR",df[i,9]))
            bowlerCount = bowlerCount + 1
            push!(bowlerSkill,raa)
            push!(bName,name)
            push!(bCost,cost)
            push!(bFit,fitness)
            push!(bOverseas,overseas)
            push!(bqualities,avg)

        elseif (occursin("BA",df[i,9]))
            batsmanCount = batsmanCount + 1
            push!(batsmanSkill,raa)
            push!(baName,name)
            push!(baCost,cost)
            push!(baFit,fitness)
            push!(baOverseas,overseas)
            push!(baqualities,avg)

        elseif (occursin("AL",df[i,9]))
            allRCount = allRCount + 1
            push!(allRSkill,raa)
            push!(arName,name)
            push!(arCost,cost)
            push!(arFit,fitness)
            push!(arOverseas,overseas)
            push!(arqualities,avg)

        elseif (occursin("WK",df[i,9]))
            wkCount = wkCount + 1
            push!(wkSkill,raa)
            push!(wktName,name)
            push!(wktCost,cost)
            push!(wktFit,fitness)
            push!(wktOverseas,overseas)
            push!(wktqualities,avg)
        end




end
return bowlerSkill, batsmanSkill, allRSkill, wkSkill, bowlerCount, batsmanCount,
allRCount, wkCount, bName, baName, arName, wktName, bCost, baCost, arCost, wktCost,
bFit, baFit, arFit, wktFit, bOverseas, baOverseas, arOverseas, wktOverseas, bqualities,
baqualities, arqualities, wktqualities
end

ballRAA=Any[]
batRAA=Any[]
rounderRAA=Any[]
wicketRAA=Any[]
ballCount=0
batCount=0
rounderCount=0
wicketCount=0
bowlerName=Any[]
batsmanName=Any[]
allRounderName=Any[]
wicketName=Any[]

bowlerCost=Any[]
batsmanCost=Any[]
allRounderCost=Any[]
wicketCost=Any[]

bowlerFit=Any[]
batsmanFit=Any[]
allRounderFit=Any[]
wicketFit=Any[]

bowlerOverseas=Any[]
batsmanOverseas=Any[]
allRounderOverseas=Any[]
wicketOverseas=Any[]

bowlerQual=Any[]
batsmanQual=Any[]
allRounderQual=Any[]
wicketQual=Any[]

ballRAA, batRAA, rounderRAA, wicketRAA, ballCount, batCount, rounderCount,
wicketCount, bowlerName, batsmanName, allRounderName, wicketName, bowlerCost,
batsmanCost, allRounderCost, wicketCost, bowlerFit, batsmanFit, allRounderFit,
wicketFit, bowlerOverseas, batsmanOverseas, allRounderOverseas,
wicketOverseas,bowlerQual,batsmanQual,allRounderQual,wicketQual = RAAScorer()

#Initializing the bowler, batsman, allRounder and wicketkeeper variables.
@variable(m, 0 ≤ bowler[1:ballCount] ≤ 1, Int)
@variable(m, 0 ≤ batsman[1:batCount] ≤ 1, Int)
@variable(m, 0 ≤ allRounder[1:rounderCount] ≤ 1, Int)
@variable(m, 0 ≤ wicketkeeper[1:wicketCount] ≤ 1, Int)

#Objective function to maximize the total team's performance.
@objective(
    m,
    Max,
    sum(ballRAA[r] * bowler[r] for r =1:ballCount) +
    sum(batRAA[s] * batsman[s] for s=1:batCount) +
    sum(rounderRAA[t] * allRounder[t] for t=1:rounderCount) +
    sum(wicketRAA[x] * wicketkeeper[x] for x=1:wicketCount)
)

#There must be 11 players
@constraint(m, sum(bowler[r] for r =1:ballCount) +
sum(batsman[s] for s=1:batCount) +
sum(allRounder[t] for t=1:rounderCount) +
sum(wicketkeeper[x] for x=1:wicketCount) == 11)

#There can be at least 5 players with bowling abilities
@constraint(m, sum(bowler[r] for r =1:ballCount) + sum(allRounder[t] for t =1:rounderCount) >= 5)

#There can be at least 4 players with batting abilities
@constraint(m, sum(batsman[s] for s =1:batCount) + sum(allRounder[t] for t =1:rounderCount)>= 4)

#There must be 2 wicketkeepers
@constraint(m, sum(wicketkeeper[r] for r =1:wicketCount) == 2)

#Fitness Constraint
for z=1:ballCount
    @constraint(m, bowlerFit[z]*bowler[z] <= 17)
end
for z=1:batCount
    @constraint(m, batsmanFit[z]*batsman[z] <= 17)
end
for z=1:rounderCount
    @constraint(m, allRounderFit[z]*allRounder[z] <= 17)
end
for z=1:wicketCount
    @constraint(m, wicketFit[z]*wicketkeeper[z] <= 17)
end

#Personality Constraint based on the average of 5 qualities
@constraint(m, sum(bowlerQual[r] * bowler[r] for r =1:ballCount) +
sum(batsmanQual[s] * batsman[s] for s=1:batCount) +
sum(allRounderQual[t] * allRounder[t] for t=1:rounderCount) +
sum(wicketQual[x] * wicketkeeper[x] for x=1:wicketCount) >= 36)

#Overseas player constraint
#At most 4 overseas players can be selected.
@constraint(m, sum(bowlerOverseas[r] * bowler[r] for r =1:ballCount) +
sum(batsmanOverseas[s] * batsman[s] for s=1:batCount) +
sum(allRounderOverseas[t] * allRounder[t] for t=1:rounderCount) +
sum(wktOverseas[x] * wicketkeeper[x] for x=1:wicketCount) >= 4)

#Budget Constraint
@constraint(m, sum(parse(Int64,bowlerCost[r]) * bowler[r] for r =1:ballCount) +
sum(parse(Int64,batsmanCost[s]) * batsman[s] for s=1:batCount) +
sum(parse(Int64,allRounderCost[t]) * allRounder[t] for t=1:rounderCount) +
sum(parse(Int64,wicketCost[x]) * wicketkeeper[x] for x=1:wicketCount) <= 5000000)


println(m)

optimize!(m)

status = termination_status(m)

println("Solution status: ", status)

println("Objective value: ", objective_value(m))

println("")
println("The optimal cricket player selection: ")
for k=1:ballCount

    if (value(bowler[k])==1.0)
        println("Bowler: ", bowlerName[k]," ")
end
end

for k=1:batCount

    if (value(batsman[k])==1.0)
        println("Batsman: ", batsmanName[k]," ")
end
end
for k=1:allRCount

    if (value(allRounder[k])==1.0)
        println("Allrounder: ",allRounderName[k]," ")
end
end
for k=1:wicketCount

    if (value(wicketkeeper[k])==1.0)
        println("Wicketkeeper: ", wicketName[k]," ")
end
end
